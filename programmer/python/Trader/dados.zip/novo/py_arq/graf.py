
import  finplot as fpt
def grafico(renk):
    fpt.candlestick_ochl(renk[['0','1','2','4','3']])

    fpt.refresh()
    fpt.show()
    