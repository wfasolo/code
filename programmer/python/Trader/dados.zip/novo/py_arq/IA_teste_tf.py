from tensorflow.keras.models import load_model
model=load_model('model_tf.m5')
def ia(dados):
    i=0
    dados=dados.reset_index(drop=True)
    m1 = ([dados['EST'][i],    dados['RSI'][i],   dados['DME'][i],   dados['TIP'][i]  ,
            dados['EST'][i+1], dados['RSI'][i+1], dados['DME'][i+1], dados['TIP'][i+1],
            dados['EST'][i+2], dados['RSI'][i+2], dados['DME'][i+2], dados['TIP'][i+2],
         ])

    y_pred = model.predict([m1])

    return y_pred