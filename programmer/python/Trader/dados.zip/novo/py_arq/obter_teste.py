import MetaTrader5 as mt5
import datetime
import pandas as pd


mt5.initialize()
ate = datetime.datetime.now()
de = ate-pd.DateOffset(hours=3)

ticks = mt5.copy_ticks_range("WINV22", de, ate,  mt5.COPY_TICKS_INFO)
data = pd.DataFrame(ticks)
ticks = pd.DataFrame([data['time'], data['bid']], index=['0', '1'])
ticks = ticks.T
ticks = ticks.loc[(ticks != 0).all(axis=1)].reset_index(drop=True)


def mt():
    global ticks
    atual = mt5.symbol_info_tick("WINV22")._asdict()
    atual2=pd.DataFrame([atual['time'],atual['bid']], index=['0', '1'])

    ticks=pd.concat([ticks,atual2.T],ignore_index=True)

    return ticks



