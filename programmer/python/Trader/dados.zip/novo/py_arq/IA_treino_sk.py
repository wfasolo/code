import joblib
from sklearn import tree
from sklearn.ensemble import RandomForestClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.neural_network import MLPClassifier


def ia(dados):
    X_train= dados[0]
    X_test=dados[1]
    y_train=dados[2]
    y_test=dados[3]

    model1 = MLPClassifier(activation='relu', solver='adam',
                           hidden_layer_sizes=(100,2), random_state=5, max_iter=2000)
    model1.fit(X_train, y_train)
    y_pred = model1.predict(X_test)
    #print(np.array(y_pred == y_test))
    m1 = model1.score(X_test, y_test)

    model2 = KNeighborsClassifier(n_neighbors=(10))
    model2.fit(X_train, y_train)
    y_pred = model2.predict(X_test)
    m2=model2.score(X_test, y_test)

    model3 = RandomForestClassifier(n_estimators=10, random_state=10)
    model3.fit(X_train, y_train)
    y_pred = model3.predict(X_test)
    m3 = model3.score(X_test, y_test)

    model4 = tree.DecisionTreeClassifier(
        criterion='entropy', min_samples_leaf=10, max_features=10)
    model4.fit(X_train, y_train)
    y_pred = model4.predict(X_test)
    m4 = model4.score(X_test, y_test)

    joblib.dump(model3, 'Trader/dados/filename.pkl')
    return [m1, m2, m3, m4]
