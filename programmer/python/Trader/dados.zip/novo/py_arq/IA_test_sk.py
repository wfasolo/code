import joblib
model4=joblib.load('Trader/dados/filename.pkl') 

def ia(dados):
    i=0
    dados=dados.reset_index(drop=True)
    m1 = ([dados['EST'][i],   dados['RSI'][i],   dados['DME'][i],   dados['TIP'][i] ,
            dados['EST'][i+1], dados['RSI'][i+1], dados['DME'][i+1], dados['TIP'][i+1],
            dados['EST'][i+2], dados['RSI'][i+2], dados['DME'][i+2], dados['TIP'][i+2],
            dados['EST'][i+3], dados['RSI'][i+3], dados['DME'][i+3], dados['TIP'][i+3],
            dados['EST'][i+4], dados['RSI'][i+4], dados['DME'][i+4], dados['TIP'][i+4]])

    y_pred = model4.predict([m1])
    porc=model4.predict_proba([m1])
    return y_pred