
import pandas as pd

rk = pd.DataFrame()


def renko(arq2):
    global rk
    arq = arq2['bid']
    par = 0
    opa = arq[0]
    p1 = 50
    tipo = tipoa = 1
    g1 = []

    if par == 0:
        p1 = 50
        tipo = tipoa = 1
        g1 = []
        a = str(int(arq[0]))

        b = a[len(a)-2]+a[len(a)-1]
        b = int(b)
        if b >= 50:
            b = b-50
        par = arq[0]-b

        opa = par

    for i in range(0, len(arq)):

        if abs(arq[i]-par) < p1:
            g1.append(arq[i])
            if tipoa == 1 and arq[i]-par < 0:
                p1 = 100
            elif tipoa == 1 and arq[i]-par > 0:
                p1 = 50
            elif tipoa == 0 and arq[i]-par < 0:
                p1 = 50
            elif tipoa == 0 and arq[i]-par > 0:
                p1 = 100

        elif len(g1) > 0:

            op = g1[:1][0]
            cl = g1[-1:][0]

            if cl-op > 0:
                tipo = 1
                g1.append(par+p1)
            else:
                tipo = 0
                g1.append(par-p1)

            op = g1[:1][0]
            cl = g1[-1:][0]
            hi = max(g1)
            lo = min(g1)
            tipoa = tipo

            if cl-op > 0:
                tipo = 1
            else:
                tipo = 0

            if abs(cl-op) > 50:
                op = opa

            par = cl
            g1 = [cl, arq[i]]
            opa = op
            cla = cl
            texto = pd.DataFrame([arq2['time'][i], op, cl, lo, hi])
            rk = pd.concat([rk, texto.T], ignore_index=True)

    rk = rk.dropna().reset_index(drop=True)
    rk = pd.DataFrame([rk[0], rk[1], rk[2], rk[3], rk[4]], index=[
        '0', '1', '2', '3', '4']).T
    return rk
