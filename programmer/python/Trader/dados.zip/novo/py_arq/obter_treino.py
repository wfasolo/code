import MetaTrader5 as mt5
import datetime
import pandas as pd
mt5.initialize()
de=datetime.datetime(2022,8,17)
ate=datetime.datetime.now()
ticks = mt5.copy_ticks_range("WINV22", de,ate,  mt5.COPY_TICKS_INFO)

data=pd.DataFrame(ticks)

ticks=pd.DataFrame([data['time'],data['bid']])
ticks=ticks.T

ticks=ticks.loc[(ticks!=0).all(axis=1)].reset_index(drop=True)
ticks.to_csv('Trader/dados/ticks.csv',decimal='.',sep=';')
print(len(ticks))




