
from threading import activeCount
import tensorflow as tf
import joblib
from tensorflow import keras
from keras.models import Sequential
from keras.layers import Dense
from sklearn.model_selection import train_test_split
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt


def ia(dados):
    dados['DATE']=pd.to_datetime(dados['DATE'], unit='s')
    matrix = []
    m_tipo = []

    linha = int(len(dados)/3)*3
    dados = dados[-linha:].reset_index(drop=True)

    for i in range(0,len(dados)-2,4):
        dth=dados['DATE'].dt.hour[i]
        dtm=dados['DATE'].dt.minute[i]
        
        if dth >8 and dtm>10 and dth<17:
            
            m1 = ([dados['EST'][i],   dados['RSI'][i],   dados['DME'][i],   dados['TIP'][i],
                dados['EST'][i+1], dados['RSI'][i+1], dados['DME'][i+1], dados['TIP'][i+1],
                dados['EST'][i+2], dados['RSI'][i+2], dados['DME'][i+2], dados['TIP'][i+2]])

            m2 = ([dados['TIP'][i+3], dados['TIP'][i+4]])

            matrix.append(m1)
            m_tipo.append(m2)

    matrix = np.array(matrix)
    m_tipo = np.array(m_tipo)

    X_train, X_test, y_train, y_test = train_test_split(
        matrix, m_tipo,
        test_size=0.2,
        shuffle=True,
        random_state=42,
        stratify=m_tipo
    )

        
    model = Sequential()
    #model.add(keras.layers.Conv1D(64, kernel_size=3, activation='softplus', padding='same', input_shape=(1,12)))
    model.add(Dense(1, activation='sigmoid', input_dim=12))

    model.add(Dense(8, activation='relu'))
   
    model.add(keras.layers.Dropout(0.2))
    model.add(Dense(2))
    print(model.summary())


        
    # Compile the model
#    model.compile(optimizer='sgd', loss='mse', metrics=['accuracy'])


    
    callback = tf.keras.callbacks.EarlyStopping(monitor='loss', min_delta=0.01)
    opt = tf.keras.optimizers.RMSprop(learning_rate=0.0001)
    model.compile(loss='MSE', optimizer='adam', metrics=['accuracy'])

    hist=model.fit(X_train, y_train, batch_size=2, epochs=150, validation_split=0.2)
    #,validation_data=(X_test, y_test), use_multiprocessing=True)
    eval=model.evaluate(X_test, y_test)
    print(eval)
    plt.plot(hist.history['accuracy'])
    plt.plot(hist.history['val_accuracy'])
    plt.plot(hist.history['loss'])
    plt.show()

    model.save('model_tf.m5') 

