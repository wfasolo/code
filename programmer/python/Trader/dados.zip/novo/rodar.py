import pandas as pd
import py_arq.renko as renko
import py_arq.prepara as prepara
import py_arq.IA_dados as IA_dados
import py_arq.IA_treino_sk as IA_tr_sk
import py_arq.graf as grafico

valor = pd.DataFrame()
valor = pd.read_csv('Trader/dados/ticks.csv', decimal='.', sep=';')

renk = renko.renko(valor)
prep = prepara.prep(renk)
IAdados = IA_dados.ia(prep)
IAtrainsk=IA_tr_sk.ia(IAdados)
print(IAtrainsk)
grafico.grafico(renk)


import  finplot as fpt

fpt.plot(prep['RSI'])
fpt.plot(prep['EST'])
fpt.plot(prep['MAC'])
fpt.refresh()
fpt.show()